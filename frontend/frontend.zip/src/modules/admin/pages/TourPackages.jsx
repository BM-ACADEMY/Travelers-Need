import React from 'react'

const TourPackages = () => {
  return (
    <div>
      Welcome to TourPackages
    </div>
  )
}

export default TourPackages;
