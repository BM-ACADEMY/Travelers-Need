import React from 'react'

const Settings = () => {
  return (
    <div>
      Welcome to Settings 
    </div>
  )
}

export default Settings;
