import React from 'react'

const Feedback = () => {
  return (
    <div>
      Welcome to Feedback
    </div>
  )
}

export default Feedback;
