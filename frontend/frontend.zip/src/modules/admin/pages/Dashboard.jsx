import React from 'react'

const Dashboard = () => {
  return (
    <div>
      Welcome to dashboard
    </div>
  )
}

export default Dashboard;
