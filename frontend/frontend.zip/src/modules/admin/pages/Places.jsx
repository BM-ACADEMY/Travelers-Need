import React from 'react'

const Places = () => {
  return (
    <div>
      Welcome to Places
    </div>
  )
}

export default Places;
