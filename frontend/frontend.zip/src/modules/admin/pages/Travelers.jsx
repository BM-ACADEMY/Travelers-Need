import React from 'react'

const Travelers = () => {
  return (
    <div>
      Welcome to Travelers
    </div>
  )
}

export default Travelers;
