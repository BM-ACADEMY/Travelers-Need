import React from 'react'

const Support = () => {
  return (
    <div>
      Welocme to Support
    </div>
  )
}

export default Support;
